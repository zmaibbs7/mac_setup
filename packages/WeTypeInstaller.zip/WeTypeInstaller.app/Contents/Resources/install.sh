#!/bin/sh

set -euo pipefail

INPUT_METHODS_DIR="/Library/Input Methods"
WETYPE_INSTALL_PATH="$INPUT_METHODS_DIR/WeType.app"
WXKB_INSTALL_PATH="$INPUT_METHODS_DIR/wxkbmac.app"
TMP_DIR="/tmp/wetype"
LOG_DIR="/tmp/wetype-install"
LOG_TIMESTAMP="$(date '+%Y%m%d_%H%M%S')"
LOG_FILE="$LOG_DIR/install_${LOG_TIMESTAMP}.log"

mkdir -p "$LOG_DIR"
exec >>"$LOG_FILE" 2>&1

timestamp() {
    date '+%H:%M:%S'
}

log() {
    local level="$1"
    shift
    echo "$(timestamp) [$level] $*"
}

dump_path() {
    local path="$1"
    if [ -e "$path" ]; then
        log INFO "path exists: $path"
        ls -lad "$path"
        if [ -d "$path" ]; then
            find "$path" -maxdepth 2 -mindepth 1 -print
        fi
    else
        log WARN "path not found: $path"
    fi
}

run_cmd() {
    log INFO "RUN: $*"
    if "$@"; then
        log INFO "OK : $*"
    else
        local code=$?
        log ERROR "FAIL($code): $*"
        exit "$code"
    fi
}

run_optional() {
    log INFO "RUN(optional): $*"
    if "$@"; then
        log INFO "OK(optional): $*"
    else
        local code=$?
        log WARN "IGNORE FAIL($code): $*"
    fi
}

stop_wetype_updaters() {
    local attempt=0

    while pgrep -x WeTypeUpdater >/dev/null 2>&1; do
        if [ "$attempt" -ge 20 ]; then
            log ERROR "old WeTypeUpdater is still running"
            return 1
        fi
        run_optional killall -9 WeTypeUpdater
        sleep 0.1
        attempt=$((attempt + 1))
    done

    log INFO "no old WeTypeUpdater is running"
}

on_error() {
    local line="$1"
    local code="$2"
    log ERROR "script aborted at line $line, exit code: $code"
}

trap 'on_error $LINENO $?' ERR

log INFO "install log: $LOG_FILE"
log INFO "shell: $0, pid: $$, interpreter: $(ps -o comm= -p $$)"
log INFO "argv: $*"
log INFO "whoami: $(whoami), uid: $(id -u), pwd: $(pwd)"

if [ $# -lt 1 ]; then
    log ERROR "missing zip path argument"
    exit 2
fi

ZIP_PATH="$1"
if [ ! -f "$ZIP_PATH" ]; then
    log ERROR "zip not found: $ZIP_PATH"
    exit 3
fi

log INFO "zip path: $ZIP_PATH"
dump_path "$INPUT_METHODS_DIR"
run_optional unzip -l "$ZIP_PATH"

log INFO "prepare temp directory: $TMP_DIR"
run_cmd rm -rf "$TMP_DIR"
run_cmd mkdir -p "$TMP_DIR"

log INFO "unzip package"
run_cmd unzip -qq "$ZIP_PATH" -d "$TMP_DIR/"
dump_path "$TMP_DIR"

if [ ! -d "$TMP_DIR/WeType.app" ]; then
    log ERROR "expected app bundle not found after unzip: $TMP_DIR/WeType.app"
    log INFO "top-level extracted entries:"
    find "$TMP_DIR" -maxdepth 2 -mindepth 1 -print
    exit 4
fi

log INFO "stop old WeTypeUpdater"
run_cmd stop_wetype_updaters
run_optional killall wxkbmac
#killall WeTypeFeedback
#killall WeType

log INFO "remove old package if needed"
if [ -d "$WXKB_INSTALL_PATH" ]; then
    run_cmd rm -rf "$WXKB_INSTALL_PATH"
fi

log INFO "target install path: $WETYPE_INSTALL_PATH"
if [ -d "$WETYPE_INSTALL_PATH" ]; then
    log INFO "remove old package: $WETYPE_INSTALL_PATH"
    run_cmd rm -rf "$WETYPE_INSTALL_PATH"
fi

log INFO "check input methods directory"
if [ -d "$INPUT_METHODS_DIR" ]; then
    log INFO "INPUT_METHODS_DIR exists"
else
    log WARN "INPUT_METHODS_DIR not exists, try create"
    run_cmd mkdir -p "$INPUT_METHODS_DIR"
fi

log INFO "move app bundle to destination directory"
run_cmd mv -f "$TMP_DIR/WeType.app" "$INPUT_METHODS_DIR/"

if [ ! -d "$WETYPE_INSTALL_PATH" ]; then
    log ERROR "install path missing after move: $WETYPE_INSTALL_PATH"
    dump_path "$INPUT_METHODS_DIR"
    exit 5
fi

dump_path "$WETYPE_INSTALL_PATH"
run_cmd chown -R root:staff "$WETYPE_INSTALL_PATH"
run_cmd chmod -R 775 "$WETYPE_INSTALL_PATH"
run_optional xattr -d -r com.apple.quarantine "$WETYPE_INSTALL_PATH"

if pgrep -x "System Preferences" >/dev/null 2>&1; then
    run_optional killall "System Preferences"
else
    log INFO "System Preferences not running"
fi
run_optional killall SystemUIServer

log INFO "final install path verification"
dump_path "$WETYPE_INSTALL_PATH"
log INFO "finish"
